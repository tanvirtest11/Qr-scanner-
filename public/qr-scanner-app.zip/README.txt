QR Scanner Mobile Application Package
=======================================

This package contains everything needed to run this QR scanner completely standalone without internet, or convert it into an Android APK directly on your phone!

FEATURES:
- Live Camera Scanner with viewfinder, laser line, flashlight/torch, and camera flip.
- High-Accuracy Gallery Photo & Screenshot Cropper (Move crop box lines, resize with corner/edge handles, rotate, and instant crop & scan).
- Scan History with individual delete & clear all history.
- Instant QR Decoder for URLs (Open & Copy), Wi-Fi (SSID & Password copy), and plain text.
- 100% Offline with zero external dependencies.
